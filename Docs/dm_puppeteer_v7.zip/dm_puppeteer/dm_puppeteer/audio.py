"""
Microphone audio level monitoring.
"""

import numpy as np
import sounddevice as sd
from PyQt6.QtCore import QObject, pyqtSignal


class AudioMonitor(QObject):
    """Monitors microphone input level using sounddevice."""

    level_changed = pyqtSignal(float)

    def __init__(self, device=None, parent=None):
        super().__init__(parent)
        self.device = device
        self.stream = None
        self.running = False

    def start(self):
        try:
            self.running = True
            self.stream = sd.InputStream(
                device=self.device,
                channels=1,
                samplerate=44100,
                blocksize=1024,
                callback=self._audio_callback
            )
            self.stream.start()
        except Exception as e:
            print(f"Audio monitor error: {e}")
            self.running = False

    def stop(self):
        self.running = False
        if self.stream:
            try:
                self.stream.stop()
                self.stream.close()
            except Exception:
                pass
            self.stream = None

    def restart(self, device=None):
        self.stop()
        if device is not None:
            self.device = device
        self.start()

    def _audio_callback(self, indata, frames, time_info, status):
        rms = float(np.sqrt(np.mean(indata ** 2)))
        self.level_changed.emit(rms)

    @staticmethod
    def list_devices():
        """Return list of input devices as (index, name) tuples."""
        devices = sd.query_devices()
        result = []
        for i, dev in enumerate(devices):
            if dev['max_input_channels'] > 0:
                result.append((i, dev['name']))
        return result
