"""
Data models and persistence for DM Puppeteer.
"""

import json
import shutil
import uuid
from pathlib import Path
from typing import Optional

from PyQt6.QtGui import QPixmap


def get_data_dir():
    import sys
    if getattr(sys, 'frozen', False):
        return Path(sys.executable).parent / "data"
    return Path(__file__).parent.parent / "data"


def get_characters_dir():
    return get_data_dir() / "characters"


# ---------------------------------------------------------------------------
# Per-character display settings
# ---------------------------------------------------------------------------

class CharacterSettings:
    """Per-character display and animation settings."""

    def __init__(self):
        self.width: int = 400
        self.height: int = 400
        self.opacity: float = 1.0

        # Blink timing
        self.blink_interval_min: float = 2.0
        self.blink_interval_max: float = 6.0
        self.blink_duration: float = 0.15

        # Bounce effect (bob up/down)
        self.bounce_enabled: bool = False
        self.bounce_amount: float = 6.0       # pixels
        self.bounce_speed: float = 3.0        # Hz
        self.bounce_on_talk_only: bool = True

        # Pop-in effect (jump on mic activate)
        self.popin_enabled: bool = False
        self.popin_amount: float = 12.0       # pixels
        self.popin_duration: float = 0.12     # seconds

        # OBS linked actions (per-character)
        self.obs_scene: str = ""              # scene to switch to (empty = don't switch)
        self.obs_text_source: str = ""        # text source to update with character name
        self.obs_show_sources: list[str] = [] # sources to show on activate
        self.obs_hide_sources: list[str] = [] # sources to hide on activate

    def to_dict(self):
        return self.__dict__.copy()

    @classmethod
    def from_dict(cls, data):
        s = cls()
        for key in s.__dict__:
            if key in data:
                setattr(s, key, data[key])
        return s


# ---------------------------------------------------------------------------
# Character
# ---------------------------------------------------------------------------

class Character:
    FRAME_NAMES = ["idle", "blink", "talk", "talk_blink"]

    def __init__(self, char_id=None, name="Unnamed", folder=None):
        self.id = char_id or str(uuid.uuid4())[:8]
        self.name = name
        self.folder = folder
        self.pixmaps: dict[str, QPixmap] = {}
        self.settings = CharacterSettings()

    def load_frames(self):
        self.pixmaps.clear()
        if not self.folder or not self.folder.exists():
            return
        for fn in self.FRAME_NAMES:
            path = self.folder / f"{fn}.png"
            if path.exists():
                pm = QPixmap(str(path))
                if not pm.isNull():
                    self.pixmaps[fn] = pm
        # Fallbacks
        if "blink" not in self.pixmaps and "idle" in self.pixmaps:
            self.pixmaps["blink"] = self.pixmaps["idle"]
        if "talk" not in self.pixmaps and "idle" in self.pixmaps:
            self.pixmaps["talk"] = self.pixmaps["idle"]
        if "talk_blink" not in self.pixmaps:
            self.pixmaps["talk_blink"] = self.pixmaps.get("blink", self.pixmaps.get("idle"))

    def get_frame(self, is_talking, is_blinking):
        if is_talking and is_blinking:
            return self.pixmaps.get("talk_blink")
        elif is_talking:
            return self.pixmaps.get("talk")
        elif is_blinking:
            return self.pixmaps.get("blink")
        return self.pixmaps.get("idle")

    def get_idle_pixmap(self):
        return self.pixmaps.get("idle")

    @property
    def is_valid(self):
        return "idle" in self.pixmaps

    def has_frame(self, frame_name):
        if not self.folder:
            return False
        return (self.folder / f"{frame_name}.png").exists()

    def set_frame_from_file(self, frame_name, source_path):
        if not self.folder:
            return
        self.folder.mkdir(parents=True, exist_ok=True)
        dest = self.folder / f"{frame_name}.png"
        shutil.copy2(source_path, dest)
        pm = QPixmap(str(dest))
        if not pm.isNull():
            self.pixmaps[frame_name] = pm

    def remove_frame(self, frame_name):
        if self.folder:
            path = self.folder / f"{frame_name}.png"
            if path.exists():
                path.unlink()
        self.pixmaps.pop(frame_name, None)
        self.load_frames()

    def to_dict(self):
        return {
            "id": self.id,
            "name": self.name,
            "folder": str(self.folder) if self.folder else None,
            "settings": self.settings.to_dict(),
        }

    @classmethod
    def from_dict(cls, data):
        char = cls(
            char_id=data.get("id"),
            name=data.get("name", "Unnamed"),
            folder=Path(data["folder"]) if data.get("folder") else None,
        )
        if "settings" in data:
            char.settings = CharacterSettings.from_dict(data["settings"])
        char.load_frames()
        return char


# ---------------------------------------------------------------------------
# PC Portrait Slot
# ---------------------------------------------------------------------------

class PCSlot:
    """A player character portrait slot with OBS audio linkage."""

    def __init__(self, slot_id=None):
        self.id = slot_id or str(uuid.uuid4())[:8]
        self.character_id: str = ""          # references a Character
        self.obs_audio_source: str = ""      # OBS input name to monitor
        self.glow_color: str = "#00cc66"     # highlight color when speaking
        self.glow_intensity: float = 1.0     # glow strength 0-1
        self.audio_threshold: float = 0.02   # sensitivity
        self.player_name: str = ""           # display name
        self.individual_x: int = -1          # saved position for individual mode
        self.individual_y: int = -1          # (-1 = auto-place)

    def to_dict(self):
        return {
            "id": self.id,
            "character_id": self.character_id,
            "obs_audio_source": self.obs_audio_source,
            "glow_color": self.glow_color,
            "glow_intensity": self.glow_intensity,
            "audio_threshold": self.audio_threshold,
            "player_name": self.player_name,
            "individual_x": self.individual_x,
            "individual_y": self.individual_y,
        }

    @classmethod
    def from_dict(cls, data):
        s = cls(slot_id=data.get("id"))
        s.character_id = data.get("character_id", "")
        s.obs_audio_source = data.get("obs_audio_source", "")
        s.glow_color = data.get("glow_color", "#00cc66")
        s.glow_intensity = data.get("glow_intensity", 1.0)
        s.audio_threshold = data.get("audio_threshold", 0.02)
        s.player_name = data.get("player_name", "")
        s.individual_x = data.get("individual_x", -1)
        s.individual_y = data.get("individual_y", -1)
        return s


# ---------------------------------------------------------------------------
# App State
# ---------------------------------------------------------------------------

class AppState:
    def __init__(self):
        self.characters: dict[str, Character] = {}
        self.deck_assignments: dict[int, str] = {}
        self.active_character_id: Optional[str] = None
        self.mic_threshold: float = 0.02
        self.mic_device: Optional[int] = None
        self.overlay_x: int = 100
        self.overlay_y: int = 100
        self.deck_mode: str = "direct"
        self.deck_brightness: int = 80
        self.hotkey_assignments: dict[int, str] = {}

        # OBS connection settings
        self.obs_host: str = "localhost"
        self.obs_port: int = 4455
        self.obs_password: str = ""
        self.obs_auto_connect: bool = False

        # PC portrait settings
        self.pc_slots: list[PCSlot] = []
        self.pc_overlay_mode: str = "strip"  # "strip" or "individual"
        self.pc_overlay_x: int = 0
        self.pc_overlay_y: int = 700
        self.pc_strip_spacing: int = 10
        self.pc_portrait_size: int = 200
        self.pc_dim_opacity: float = 0.4     # opacity for non-speaking PCs
        self.pc_shade_amount: float = 0.0    # dark overlay on non-speaking (0=off, 1=silhouette)

        # Discord bot settings
        self.discord_token: str = ""
        self.discord_roll_channel_id: int = 0
        self.discord_auto_connect: bool = False
        self.dice_overlay_x: int = 50
        self.dice_overlay_y: int = 50
        self.dice_display_time: float = 6.0

    def get_active_character(self):
        if self.active_character_id and self.active_character_id in self.characters:
            return self.characters[self.active_character_id]
        return None

    def add_character(self, char):
        self.characters[char.id] = char

    def remove_character(self, char_id):
        self.characters.pop(char_id, None)
        to_remove = [k for k, v in self.deck_assignments.items() if v == char_id]
        for k in to_remove:
            del self.deck_assignments[k]
        if self.active_character_id == char_id:
            self.active_character_id = None

    def get_character_for_button(self, button_index):
        cid = self.deck_assignments.get(button_index)
        if cid and cid in self.characters:
            return self.characters[cid]
        return None

    def assign_character_to_button(self, btn, cid):
        self.deck_assignments[btn] = cid

    def unassign_button(self, btn):
        self.deck_assignments.pop(btn, None)

    def save(self, path=None):
        if path is None:
            path = get_data_dir() / "state.json"
        path.parent.mkdir(parents=True, exist_ok=True)
        data = {
            "characters": [c.to_dict() for c in self.characters.values()],
            "deck_assignments": {str(k): v for k, v in self.deck_assignments.items()},
            "hotkey_assignments": {str(k): v for k, v in self.hotkey_assignments.items()},
            "active_character_id": self.active_character_id,
            "mic_threshold": self.mic_threshold,
            "mic_device": self.mic_device,
            "overlay_x": self.overlay_x,
            "overlay_y": self.overlay_y,
            "deck_mode": self.deck_mode,
            "deck_brightness": self.deck_brightness,
            "obs_host": self.obs_host,
            "obs_port": self.obs_port,
            "obs_password": self.obs_password,
            "obs_auto_connect": self.obs_auto_connect,
            "pc_slots": [s.to_dict() for s in self.pc_slots],
            "pc_overlay_mode": self.pc_overlay_mode,
            "pc_overlay_x": self.pc_overlay_x,
            "pc_overlay_y": self.pc_overlay_y,
            "pc_strip_spacing": self.pc_strip_spacing,
            "pc_portrait_size": self.pc_portrait_size,
            "pc_dim_opacity": self.pc_dim_opacity,
            "pc_shade_amount": self.pc_shade_amount,
            "discord_token": self.discord_token,
            "discord_roll_channel_id": self.discord_roll_channel_id,
            "discord_auto_connect": self.discord_auto_connect,
            "dice_overlay_x": self.dice_overlay_x,
            "dice_overlay_y": self.dice_overlay_y,
            "dice_display_time": self.dice_display_time,
        }
        with open(path, 'w') as f:
            json.dump(data, f, indent=2)

    @classmethod
    def load(cls, path=None):
        if path is None:
            path = get_data_dir() / "state.json"
        state = cls()
        if not path.exists():
            return state
        try:
            with open(path, 'r') as f:
                data = json.load(f)
        except (json.JSONDecodeError, IOError):
            return state

        for cdata in data.get("characters", []):
            try:
                char = Character.from_dict(cdata)
                state.characters[char.id] = char
            except Exception as e:
                print(f"Warning: Could not load character: {e}")

        state.deck_assignments = {int(k): v for k, v in data.get("deck_assignments", {}).items()}
        state.hotkey_assignments = {int(k): v for k, v in data.get("hotkey_assignments", {}).items()}
        state.active_character_id = data.get("active_character_id")
        state.mic_threshold = data.get("mic_threshold", 0.02)
        state.mic_device = data.get("mic_device")
        state.overlay_x = data.get("overlay_x", 100)
        state.overlay_y = data.get("overlay_y", 100)
        state.deck_mode = data.get("deck_mode", "direct")
        state.deck_brightness = data.get("deck_brightness", 80)
        state.obs_host = data.get("obs_host", "localhost")
        state.obs_port = data.get("obs_port", 4455)
        state.obs_password = data.get("obs_password", "")
        state.obs_auto_connect = data.get("obs_auto_connect", False)

        for sdata in data.get("pc_slots", []):
            try:
                state.pc_slots.append(PCSlot.from_dict(sdata))
            except Exception:
                pass
        state.pc_overlay_mode = data.get("pc_overlay_mode", "strip")
        state.pc_overlay_x = data.get("pc_overlay_x", 0)
        state.pc_overlay_y = data.get("pc_overlay_y", 700)
        state.pc_strip_spacing = data.get("pc_strip_spacing", 10)
        state.pc_portrait_size = data.get("pc_portrait_size", 200)
        state.pc_dim_opacity = data.get("pc_dim_opacity", 0.4)
        state.pc_shade_amount = data.get("pc_shade_amount", 0.0)
        state.discord_token = data.get("discord_token", "")
        state.discord_roll_channel_id = data.get("discord_roll_channel_id", 0)
        state.discord_auto_connect = data.get("discord_auto_connect", False)
        state.dice_overlay_x = data.get("dice_overlay_x", 50)
        state.dice_overlay_y = data.get("dice_overlay_y", 50)
        state.dice_display_time = data.get("dice_display_time", 6.0)
        return state
