"""
Dice Roll Overlay.

Animated transparent overlay that shows dice rolls on stream.
Rolls slide in, display for a few seconds, then fade out.
Supports theming per character via glow color.
"""

import time
import math

from PyQt6.QtWidgets import QMainWindow, QWidget
from PyQt6.QtCore import Qt, QTimer, pyqtSignal, QRect, QPropertyAnimation, QEasingCurve
from PyQt6.QtGui import (
    QPainter, QColor, QFont, QPen, QLinearGradient,
    QPainterPath, QFontMetrics
)

from .discord_bot import DiceRollEvent


class DiceRollCard:
    """Data + animation state for one dice roll display."""

    def __init__(self, event: DiceRollEvent, color: str = "#00cc66"):
        self.event = event
        self.color = QColor(color)
        self.created = time.monotonic()

        # Animation state
        self.opacity = 0.0       # 0-1
        self.slide_x = -400.0    # starts off-screen left
        self.phase = "enter"     # enter, hold, exit, done

    def update(self, display_time: float = 6.0, dt: float = 0.033):
        """Update animation state. Returns True if still alive."""
        age = time.monotonic() - self.created

        if self.phase == "enter":
            # Slide in + fade in over 0.4s
            t = min(age / 0.4, 1.0)
            ease = 1.0 - (1.0 - t) ** 3  # ease-out cubic
            self.slide_x = -400.0 * (1.0 - ease)
            self.opacity = ease
            if t >= 1.0:
                self.phase = "hold"
                self.slide_x = 0.0
                self.opacity = 1.0

        elif self.phase == "hold":
            hold_start = 0.4
            if age > hold_start + display_time:
                self.phase = "exit"

        elif self.phase == "exit":
            exit_start = 0.4 + display_time
            t = min((age - exit_start) / 0.5, 1.0)
            self.opacity = 1.0 - t
            self.slide_x = 100.0 * t  # drift right while fading
            if t >= 1.0:
                self.phase = "done"

        return self.phase != "done"


class DiceRollOverlay(QMainWindow):
    """Transparent overlay window that displays dice roll cards."""

    position_changed = pyqtSignal(int, int)

    CARD_WIDTH = 380
    CARD_HEIGHT = 100
    CARD_SPACING = 8
    MAX_VISIBLE = 4

    def __init__(self, x=50, y=50):
        super().__init__()
        self.cards: list[DiceRollCard] = []
        self._display_time = 6.0
        self._drag_pos = None

        # Character → color mapping (set from PC slots or manually)
        self.character_colors: dict[str, str] = {}

        self.setWindowTitle("DM Puppeteer — Dice Rolls")
        self.setWindowFlags(
            Qt.WindowType.FramelessWindowHint |
            Qt.WindowType.WindowStaysOnTopHint |
            Qt.WindowType.Tool
        )
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)
        self.resize(self.CARD_WIDTH + 20, 
                    self.MAX_VISIBLE * (self.CARD_HEIGHT + self.CARD_SPACING) + 20)
        self.move(x, y)

        self.canvas = _DiceCanvas(self)
        self.setCentralWidget(self.canvas)

        self.render_timer = QTimer(self)
        self.render_timer.timeout.connect(self._tick)
        self.render_timer.start(33)

    def set_display_time(self, seconds: float):
        self._display_time = max(1.0, seconds)

    def add_roll(self, event: DiceRollEvent):
        """Add a new dice roll to display."""
        # Find color for this character
        color = "#00cc66"
        name_lower = event.character_name.lower()
        for key, c in self.character_colors.items():
            if key.lower() in name_lower or name_lower in key.lower():
                color = c
                break

        card = DiceRollCard(event, color)
        self.cards.append(card)

        # Trim old cards
        while len(self.cards) > self.MAX_VISIBLE + 2:
            self.cards.pop(0)

    def _tick(self):
        # Update all cards
        self.cards = [c for c in self.cards
                      if c.update(self._display_time)]
        self.canvas.update()

    # Draggable
    def mousePressEvent(self, event):
        if event.button() == Qt.MouseButton.LeftButton:
            self._drag_pos = (event.globalPosition().toPoint()
                              - self.frameGeometry().topLeft())

    def mouseMoveEvent(self, event):
        if self._drag_pos and event.buttons() & Qt.MouseButton.LeftButton:
            self.move(event.globalPosition().toPoint() - self._drag_pos)

    def mouseReleaseEvent(self, event):
        if self._drag_pos:
            pos = self.pos()
            self.position_changed.emit(pos.x(), pos.y())
        self._drag_pos = None


class _DiceCanvas(QWidget):
    def __init__(self, overlay: DiceRollOverlay):
        super().__init__(overlay)
        self.overlay = overlay

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        painter.setRenderHint(QPainter.RenderHint.SmoothPixmapTransform)

        ov = self.overlay
        y_offset = 10

        # Draw cards from newest at top
        visible = [c for c in ov.cards if c.phase != "done"]
        for card in visible[-ov.MAX_VISIBLE:]:
            self._paint_card(painter, card, 10 + int(card.slide_x),
                             y_offset, ov.CARD_WIDTH, ov.CARD_HEIGHT)
            y_offset += ov.CARD_HEIGHT + ov.CARD_SPACING

        painter.end()

    def _paint_card(self, painter: QPainter, card: DiceRollCard,
                    x: int, y: int, w: int, h: int):
        """Paint a single dice roll card."""
        painter.save()
        painter.setOpacity(card.opacity)

        evt = card.event
        color = card.color
        rect = QRect(x, y, w, h)

        # Background with gradient
        path = QPainterPath()
        path.addRoundedRect(float(x), float(y), float(w), float(h), 10, 10)

        grad = QLinearGradient(x, y, x + w, y)
        grad.setColorAt(0, QColor(20, 20, 25, 230))
        grad.setColorAt(1, QColor(30, 30, 40, 220))
        painter.fillPath(path, grad)

        # Colored accent bar on left
        accent_path = QPainterPath()
        accent_path.addRoundedRect(float(x), float(y), 6, float(h), 3, 3)
        painter.fillPath(accent_path, color)

        # Glow border for crits
        if evt.is_critical:
            glow = QColor(255, 215, 0, 150)  # gold
            painter.setPen(QPen(glow, 2))
            painter.drawRoundedRect(rect.adjusted(0, 0, 0, 0), 10, 10)
        elif evt.is_fumble:
            glow = QColor(255, 50, 50, 150)  # red
            painter.setPen(QPen(glow, 2))
            painter.drawRoundedRect(rect.adjusted(0, 0, 0, 0), 10, 10)
        else:
            painter.setPen(QPen(QColor(color.red(), color.green(),
                                       color.blue(), 80), 1))
            painter.drawRoundedRect(rect.adjusted(0, 0, 0, 0), 10, 10)

        # Character name
        painter.setPen(QColor(255, 255, 255, 240))
        name_font = QFont("Segoe UI", 11, QFont.Weight.Bold)
        painter.setFont(name_font)
        name_rect = QRect(x + 14, y + 6, w - 100, 22)
        painter.drawText(name_rect, Qt.AlignmentFlag.AlignLeft |
                         Qt.AlignmentFlag.AlignVCenter,
                         evt.character_name)

        # Check type (smaller, muted)
        painter.setPen(QColor(180, 180, 200, 200))
        type_font = QFont("Segoe UI", 9)
        painter.setFont(type_font)
        type_rect = QRect(x + 14, y + 28, w - 100, 18)
        painter.drawText(type_rect, Qt.AlignmentFlag.AlignLeft |
                         Qt.AlignmentFlag.AlignVCenter,
                         evt.check_type)

        # Roll formula
        painter.setPen(QColor(160, 160, 180, 180))
        formula_font = QFont("Consolas", 9)
        painter.setFont(formula_font)
        formula_rect = QRect(x + 14, y + 48, w - 100, 18)
        formula_text = evt.roll_formula
        # Clean up markdown artifacts
        formula_text = formula_text.replace('**', '').replace('`', '')
        painter.drawText(formula_rect, Qt.AlignmentFlag.AlignLeft |
                         Qt.AlignmentFlag.AlignVCenter,
                         formula_text)

        # Campaign name (small, at bottom)
        if evt.campaign_name:
            painter.setPen(QColor(120, 120, 140, 140))
            camp_font = QFont("Segoe UI", 7, QFont.Weight.Normal,
                              italic=True)
            painter.setFont(camp_font)
            camp_rect = QRect(x + 14, y + h - 20, w - 100, 16)
            painter.drawText(camp_rect, Qt.AlignmentFlag.AlignLeft |
                             Qt.AlignmentFlag.AlignVCenter,
                             evt.campaign_name)

        # Total (big number on right)
        total_str = str(evt.total)

        # Color based on result type
        if evt.is_critical:
            total_color = QColor(255, 215, 0)       # gold
            total_label = "NAT 20!"
        elif evt.is_fumble:
            total_color = QColor(255, 60, 60)        # red
            total_label = "NAT 1"
        else:
            total_color = QColor(color.lighter(130))
            total_label = ""

        # Big total number
        total_font = QFont("Segoe UI", 28, QFont.Weight.Bold)
        painter.setFont(total_font)
        painter.setPen(total_color)
        total_rect = QRect(x + w - 90, y + 8, 80, 50)
        painter.drawText(total_rect, Qt.AlignmentFlag.AlignCenter,
                         total_str)

        # Crit/fumble label
        if total_label:
            label_font = QFont("Segoe UI", 8, QFont.Weight.Bold)
            painter.setFont(label_font)
            painter.setPen(total_color)
            label_rect = QRect(x + w - 90, y + 58, 80, 16)
            painter.drawText(label_rect, Qt.AlignmentFlag.AlignCenter,
                             total_label)

        # Natural roll indicator (small d20 icon)
        if evt.natural_roll > 0:
            painter.setPen(QColor(140, 140, 160, 160))
            d20_font = QFont("Segoe UI", 8)
            painter.setFont(d20_font)
            d20_rect = QRect(x + w - 90, y + h - 22, 80, 16)
            painter.drawText(d20_rect, Qt.AlignmentFlag.AlignCenter,
                             f"🎲 d20 → {evt.natural_roll}")

        painter.restore()
