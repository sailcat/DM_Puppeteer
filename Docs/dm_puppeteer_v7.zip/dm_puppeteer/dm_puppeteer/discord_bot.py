"""
Discord Bot Bridge.

Runs a Discord bot in a background thread and bridges events
to the Qt main thread via signals. Monitors:
  - Voice state (who's speaking) for PC portraits
  - Avrae dice roll messages for stream overlays
  - Custom commands for DM tools
"""

import asyncio
import json
import re
import threading
import queue
from dataclasses import dataclass, field
from typing import Optional

from PyQt6.QtCore import QObject, pyqtSignal, QTimer

try:
    import discord
    from discord import Intents
    DISCORD_AVAILABLE = True
except ImportError:
    DISCORD_AVAILABLE = False


# ---------------------------------------------------------------------------
# Event data classes
# ---------------------------------------------------------------------------

@dataclass
class VoiceStateEvent:
    """A user's voice state changed."""
    user_id: int
    username: str
    display_name: str
    is_speaking: bool = False
    is_muted: bool = False
    is_deafened: bool = False
    joined: bool = False
    left: bool = False


@dataclass
class DiceRollEvent:
    """A dice roll was detected from Avrae / D&D Beyond."""
    character_name: str = ""
    check_type: str = ""       # "Deception check", "Attack", "Saving Throw"
    roll_formula: str = ""     # "1d20 (13) + 6"
    natural_roll: int = 0      # the d20 result
    total: int = 0
    is_critical: bool = False  # nat 20
    is_fumble: bool = False    # nat 1
    campaign_name: str = ""
    raw_text: str = ""


@dataclass
class CommandEvent:
    """A custom command was issued in Discord."""
    command: str = ""
    args: list = field(default_factory=list)
    user: str = ""
    channel: str = ""


# ---------------------------------------------------------------------------
# Avrae Message Parser
# ---------------------------------------------------------------------------

class AvraeParser:
    """Parse Avrae bot messages and D&D Beyond roll messages."""

    # Avrae's bot ID (official)
    AVRAE_BOT_ID = 261302296103747584

    # Pattern: "Character Name makes a Skill check!"
    # or "Character Name makes a Strength saving throw!"
    CHECK_PATTERN = re.compile(
        r'^(.+?)\s+makes?\s+(?:a |an )?(.+?)!?\s*$',
        re.IGNORECASE
    )

    # Pattern: dice formula like "1d20 (13) + 6 = 19"
    ROLL_PATTERN = re.compile(
        r'(\d+d\d+)\s*\((\d+)\)\s*(.*?)\s*=\s*(\d+)',
        re.IGNORECASE
    )

    # Pattern: "Rolled in Campaign Name"
    CAMPAIGN_PATTERN = re.compile(
        r'Rolled\s+in\s+(.+)',
        re.IGNORECASE
    )

    # Attack patterns from Avrae commands
    ATTACK_PATTERN = re.compile(
        r'^(.+?)\s+attacks?\s+with\s+(?:a |an |their )?(.+?)!?\s*$',
        re.IGNORECASE
    )

    @classmethod
    def parse_message(cls, content: str, embeds: list = None) -> Optional[DiceRollEvent]:
        """Try to parse a dice roll from message content or embeds."""

        # Try plain text first (D&D Beyond campaign integration format)
        event = cls._parse_text(content)
        if event:
            return event

        # Try embeds (Avrae command format)
        if embeds:
            for embed in embeds:
                event = cls._parse_embed(embed)
                if event:
                    return event

        return None

    @classmethod
    def _parse_text(cls, text: str) -> Optional[DiceRollEvent]:
        """Parse plain text roll messages (D&D Beyond → Avrae format)."""
        if not text or len(text) < 10:
            return None

        lines = [l.strip() for l in text.strip().split('\n') if l.strip()]
        if len(lines) < 2:
            return None

        event = DiceRollEvent(raw_text=text)

        # Line 1: "Character makes a Check!"
        check_match = cls.CHECK_PATTERN.match(lines[0])
        attack_match = cls.ATTACK_PATTERN.match(lines[0])

        if check_match:
            event.character_name = check_match.group(1).strip()
            event.check_type = check_match.group(2).strip()
        elif attack_match:
            event.character_name = attack_match.group(1).strip()
            event.check_type = f"Attack: {attack_match.group(2).strip()}"
        else:
            # Try to extract name from first line anyway
            event.character_name = lines[0].rstrip('!').strip()

        # Line 2+: dice formula "1d20 (13) + 6 = 19"
        for line in lines[1:]:
            roll_match = cls.ROLL_PATTERN.search(line)
            if roll_match:
                event.roll_formula = line.strip()
                event.natural_roll = int(roll_match.group(2))
                event.total = int(roll_match.group(4))
                event.is_critical = event.natural_roll == 20
                event.is_fumble = event.natural_roll == 1
                break

        # Campaign line
        for line in lines:
            camp_match = cls.CAMPAIGN_PATTERN.match(line)
            if camp_match:
                event.campaign_name = camp_match.group(1).strip()

        # Only return if we got something meaningful
        if event.character_name and event.total > 0:
            return event
        return None

    @classmethod
    def _parse_embed(cls, embed) -> Optional[DiceRollEvent]:
        """Parse Avrae-style embed messages."""
        event = DiceRollEvent()

        # Avrae embeds typically have the character name in author
        if hasattr(embed, 'author') and embed.author:
            event.character_name = embed.author.name or ""

        # Title often has the roll type
        if hasattr(embed, 'title') and embed.title:
            event.check_type = embed.title

        # Description has the roll details
        desc = ""
        if hasattr(embed, 'description') and embed.description:
            desc = embed.description
            event.raw_text = desc

        # Parse dice from description
        roll_match = cls.ROLL_PATTERN.search(desc)
        if roll_match:
            event.roll_formula = desc.strip()
            event.natural_roll = int(roll_match.group(2))
            event.total = int(roll_match.group(4))
            event.is_critical = event.natural_roll == 20
            event.is_fumble = event.natural_roll == 1

        # Check fields for additional data
        if hasattr(embed, 'fields'):
            for f in embed.fields:
                name = (f.name or "").lower()
                val = f.value or ""
                if "result" in name or "total" in name:
                    try:
                        event.total = int(re.search(r'\d+', val).group())
                    except (AttributeError, ValueError):
                        pass

        # Footer often has campaign info
        if hasattr(embed, 'footer') and embed.footer and embed.footer.text:
            camp_match = cls.CAMPAIGN_PATTERN.match(embed.footer.text)
            if camp_match:
                event.campaign_name = camp_match.group(1).strip()

        if event.character_name and event.total > 0:
            return event
        return None


# ---------------------------------------------------------------------------
# Discord Bot (runs in background thread)
# ---------------------------------------------------------------------------

class _DiscordBotRunner:
    """Internal bot runner that executes in a background thread."""

    def __init__(self, token: str, event_queue: queue.Queue,
                 roll_channel_id: int = 0, guild_id: int = 0):
        self.token = token
        self.event_queue = event_queue
        self.roll_channel_id = roll_channel_id
        self.guild_id = guild_id
        self.loop = None
        self.client = None
        self._running = False

    def run(self):
        """Run the bot (called from background thread)."""
        if not DISCORD_AVAILABLE:
            self.event_queue.put(("error", "discord.py not installed"))
            return

        self.loop = asyncio.new_event_loop()
        asyncio.set_event_loop(self.loop)

        intents = Intents.default()
        intents.message_content = True
        intents.voice_states = True
        intents.guilds = True
        intents.members = True

        self.client = discord.Client(intents=intents)
        self._setup_handlers()

        try:
            self.loop.run_until_complete(self.client.start(self.token))
        except discord.LoginFailure:
            self.event_queue.put(("error", "Invalid bot token"))
        except Exception as e:
            self.event_queue.put(("error", str(e)))
        finally:
            self._running = False

    def stop(self):
        """Request the bot to stop."""
        self._running = False
        if self.client and self.loop:
            asyncio.run_coroutine_threadsafe(self.client.close(), self.loop)

    def _setup_handlers(self):
        client = self.client

        @client.event
        async def on_ready():
            self._running = True
            guild_count = len(client.guilds)
            guild_names = [g.name for g in client.guilds]
            self.event_queue.put(("connected", {
                "bot_name": client.user.name,
                "guild_count": guild_count,
                "guilds": guild_names,
            }))

        @client.event
        async def on_message(message):
            # Skip own messages
            if message.author == client.user:
                return

            # Check for dice rolls in the roll channel
            if self.roll_channel_id and message.channel.id == self.roll_channel_id:
                self._handle_roll_message(message)
            elif message.author.bot and message.author.id == AvraeParser.AVRAE_BOT_ID:
                # Avrae messages in any channel
                self._handle_roll_message(message)

            # Check for custom commands (messages starting with !pm)
            if message.content.startswith("!pm "):
                parts = message.content[4:].strip().split()
                if parts:
                    cmd_event = CommandEvent(
                        command=parts[0],
                        args=parts[1:],
                        user=message.author.display_name,
                        channel=message.channel.name,
                    )
                    self.event_queue.put(("command", cmd_event))

        @client.event
        async def on_voice_state_update(member, before, after):
            # User joined a voice channel
            if before.channel is None and after.channel is not None:
                evt = VoiceStateEvent(
                    user_id=member.id,
                    username=member.name,
                    display_name=member.display_name,
                    joined=True,
                    is_muted=after.self_mute or after.mute,
                    is_deafened=after.self_deaf or after.deaf,
                )
                self.event_queue.put(("voice_state", evt))

            # User left a voice channel
            elif before.channel is not None and after.channel is None:
                evt = VoiceStateEvent(
                    user_id=member.id,
                    username=member.name,
                    display_name=member.display_name,
                    left=True,
                )
                self.event_queue.put(("voice_state", evt))

            # User muted/unmuted/deafened
            elif before.channel is not None and after.channel is not None:
                evt = VoiceStateEvent(
                    user_id=member.id,
                    username=member.name,
                    display_name=member.display_name,
                    is_muted=after.self_mute or after.mute,
                    is_deafened=after.self_deaf or after.deaf,
                )
                self.event_queue.put(("voice_state", evt))

    def _handle_roll_message(self, message):
        """Parse a potential dice roll message."""
        # Try content first
        content = message.content or ""

        # Also check embeds
        embeds = message.embeds if message.embeds else []

        event = AvraeParser.parse_message(content, embeds)
        if event:
            self.event_queue.put(("dice_roll", event))


# ---------------------------------------------------------------------------
# Qt Bridge (main thread interface)
# ---------------------------------------------------------------------------

class DiscordBridge(QObject):
    """Bridges Discord bot events to the Qt main thread."""

    # Signals
    connection_changed = pyqtSignal(bool, str)    # connected, info
    dice_roll = pyqtSignal(object)                # DiceRollEvent
    voice_state = pyqtSignal(object)              # VoiceStateEvent
    command_received = pyqtSignal(object)          # CommandEvent
    error_occurred = pyqtSignal(str)

    def __init__(self, parent=None):
        super().__init__(parent)
        self._event_queue = queue.Queue()
        self._bot_runner = None
        self._bot_thread = None
        self._connected = False

        # Poll queue every 50ms
        self._poll_timer = QTimer(self)
        self._poll_timer.timeout.connect(self._poll_events)

    @property
    def is_connected(self):
        return self._connected

    def connect(self, token: str, roll_channel_id: int = 0, guild_id: int = 0):
        """Start the Discord bot in a background thread."""
        if not DISCORD_AVAILABLE:
            self.error_occurred.emit(
                "discord.py not installed.\n"
                "Run: pip install discord.py[voice]")
            self.connection_changed.emit(False, "Library not installed")
            return

        if self._connected:
            self.disconnect()

        self._event_queue = queue.Queue()
        self._bot_runner = _DiscordBotRunner(
            token=token,
            event_queue=self._event_queue,
            roll_channel_id=roll_channel_id,
            guild_id=guild_id,
        )

        self._bot_thread = threading.Thread(
            target=self._bot_runner.run,
            daemon=True,
            name="discord-bot"
        )
        self._bot_thread.start()
        self._poll_timer.start(50)
        self.connection_changed.emit(False, "Connecting...")

    def disconnect(self):
        """Stop the Discord bot."""
        self._poll_timer.stop()
        if self._bot_runner:
            self._bot_runner.stop()
            self._bot_runner = None
        if self._bot_thread and self._bot_thread.is_alive():
            self._bot_thread.join(timeout=5)
        self._bot_thread = None
        self._connected = False
        self.connection_changed.emit(False, "Disconnected")

    def _poll_events(self):
        """Drain the event queue and emit signals (runs on main thread)."""
        while True:
            try:
                event_type, data = self._event_queue.get_nowait()
            except queue.Empty:
                break

            if event_type == "connected":
                self._connected = True
                info = data
                self.connection_changed.emit(
                    True,
                    f"{info['bot_name']} — {info['guild_count']} server(s)"
                )

            elif event_type == "dice_roll":
                self.dice_roll.emit(data)

            elif event_type == "voice_state":
                self.voice_state.emit(data)

            elif event_type == "command":
                self.command_received.emit(data)

            elif event_type == "error":
                self._connected = False
                self.error_occurred.emit(str(data))
                self.connection_changed.emit(False, f"Error: {data}")
