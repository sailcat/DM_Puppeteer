#!/usr/bin/env python3
"""
DM Puppeteer — Animated NPC Portrait Overlay for D&D Streaming
=============================================================
Run this file to start the application.

Usage:
    python run.py
"""

import sys
from PyQt6.QtWidgets import QApplication
from dm_puppeteer.models import AppState
from dm_puppeteer.app_window import AppWindow


def main():
    # Load saved state
    state = AppState.load()

    # Create Qt application
    app = QApplication(sys.argv)
    app.setApplicationName("DM Puppeteer")
    app.setQuitOnLastWindowClosed(False)  # Keep running in tray

    # Create and show the control panel
    window = AppWindow(state)
    window.show()

    # Clean shutdown
    app.aboutToQuit.connect(window.shutdown)

    sys.exit(app.exec())


if __name__ == "__main__":
    main()
